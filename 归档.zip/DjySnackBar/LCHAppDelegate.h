//
//  LCHAppDelegate.h
//  DjySnackBar
//
//  Created by 林灿涵 on 14-3-14.
//  Copyright (c) 2014年 林灿涵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMapKit.h"

@interface LCHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic)BMKMapManager *mapManager;

@end


