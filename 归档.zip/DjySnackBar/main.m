//
//  main.m
//  DjySnackBar
//
//  Created by 林灿涵 on 14-3-14.
//  Copyright (c) 2014年 林灿涵. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LCHAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LCHAppDelegate class]));
    }
}
